#!/usr/bin/env python
from bots import grammarcheck

if __name__ == '__main__':
    grammarcheck.start()
    #~ grammarcheck.startmulti('bots/usersys/grammars/edifact/*','edifact')     #for bulk check of grammars
