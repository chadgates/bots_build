#!/usr/bin/env python
from bots import engine2

if __name__ == '__main__':
    engine2.start()
