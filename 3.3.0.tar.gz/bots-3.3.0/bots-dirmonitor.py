#!/usr/bin/env python
from bots import dirmonitor

if __name__ == '__main__':
    dirmonitor.start()
