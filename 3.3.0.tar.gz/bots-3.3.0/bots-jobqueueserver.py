#!/usr/bin/env python
from bots import jobqueueserver

if __name__ == '__main__':
    jobqueueserver.start()
