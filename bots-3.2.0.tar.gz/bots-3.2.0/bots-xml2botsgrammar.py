#!/usr/bin/env python
from bots import xml2botsgrammar

if __name__ == '__main__':
    xml2botsgrammar.start()
