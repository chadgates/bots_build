DROP TABLE uniek ;

CREATE TABLE uniek (
domein varchar(35) PRIMARY KEY NOT NULL,
nummer integer NOT NULL DEFAULT 1
);
