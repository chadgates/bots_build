#!/usr/bin/env python
from bots import botsupdatedb

if __name__ == '__main__':
    botsupdatedb.start()
